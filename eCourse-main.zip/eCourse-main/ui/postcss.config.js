export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
    rfs: {},
    "postcss-pxtorem": { propList: ["*"] },
  },
};
